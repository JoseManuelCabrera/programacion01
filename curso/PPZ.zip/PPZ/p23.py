http://www.codeskulptor.org/
