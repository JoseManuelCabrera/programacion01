import webbrowser
webbrowser.open("http://pyladies.com")
